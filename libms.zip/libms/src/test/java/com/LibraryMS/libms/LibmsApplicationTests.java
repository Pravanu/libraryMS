package com.LibraryMS.libms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
