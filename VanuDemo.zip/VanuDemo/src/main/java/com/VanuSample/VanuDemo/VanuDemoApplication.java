package com.VanuSample.VanuDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VanuDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(VanuDemoApplication.class, args);
	}

}
