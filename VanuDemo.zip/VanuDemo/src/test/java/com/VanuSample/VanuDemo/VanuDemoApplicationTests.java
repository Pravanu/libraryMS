package com.VanuSample.VanuDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VanuDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
