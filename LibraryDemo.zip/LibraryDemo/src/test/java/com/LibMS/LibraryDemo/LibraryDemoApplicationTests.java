package com.LibMS.LibraryDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
