package com.springLms.BootLibms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootLibmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
