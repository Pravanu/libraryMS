package com.NewLibBoot.LibNew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibNewApplication.class, args);
	}

}
