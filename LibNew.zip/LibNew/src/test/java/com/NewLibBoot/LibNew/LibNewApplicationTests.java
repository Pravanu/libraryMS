package com.NewLibBoot.LibNew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
